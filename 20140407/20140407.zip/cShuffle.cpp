#include "StdAfx.h"
#include "cShuffle.h"

cShuffle::cShuffle(void)
{
}

cShuffle::~cShuffle(void)
{
}
